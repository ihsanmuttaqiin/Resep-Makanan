package com.azhar.resepmakanan.networking

/**
 * Created by Azhar Rivaldi on 22-12-2019.
 */

object Api {

    var Categories = "https://www.themealdb.com/api/json/v1/1/categories.php"
    var Filter = "https://www.themealdb.com/api/json/v1/1/filter.php?c={strCategory}"
    var DetailRecipe = "https://www.themealdb.com/api/json/v1/1/lookup.php?i={idMeal}"

}